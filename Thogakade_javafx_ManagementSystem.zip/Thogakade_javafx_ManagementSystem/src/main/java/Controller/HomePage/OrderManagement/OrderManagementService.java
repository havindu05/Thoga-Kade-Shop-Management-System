package Controller.HomePage.OrderManagement;

import javafx.collections.ObservableList;
import model.dto.OrdersDTO;

public interface OrderManagementService {

    void addOrder(OrdersDTO order);

    void updateOrder(OrdersDTO order);

    void deleteOrder(String id);

    OrdersDTO searchOrder(String id);

    ObservableList<OrdersDTO> getAllOrders();
}
