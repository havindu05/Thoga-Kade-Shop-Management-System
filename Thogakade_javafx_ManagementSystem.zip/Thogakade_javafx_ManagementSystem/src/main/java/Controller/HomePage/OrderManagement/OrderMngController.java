package Controller.HomePage.OrderManagement;

import db.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.dto.OrdersDTO;

import java.sql.*;

public class OrderMngController implements OrderManagementService {

    @Override
    public void addOrder(OrdersDTO order) {
        String sql = "INSERT INTO Orders(id, date, customerId) VALUES(?, ?, ?)";

        try {
            Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement pstm = connection.prepareStatement(sql);

            pstm.setString(1, order.getId());
            pstm.setString(2, order.getDate());
            pstm.setString(3, order.getCustomerId());

            pstm.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Add Order Error: " + e.getMessage());
        }
    }

    @Override
    public void updateOrder(OrdersDTO order) {
        String sql = "UPDATE Orders SET date=?, customerId=? WHERE id=?";

        try {
            Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement pstm = connection.prepareStatement(sql);

            pstm.setString(1, order.getDate());
            pstm.setString(2, order.getCustomerId());
            pstm.setString(3, order.getId());

            pstm.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Update Error: " + e.getMessage());
        }
    }

    @Override
    public void deleteOrder(String id) {
        String sql = "DELETE FROM Orders WHERE id=?";

        try {
            Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement pstm = connection.prepareStatement(sql);

            pstm.setString(1, id);
            pstm.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Delete Error: " + e.getMessage());
        }
    }

    @Override
    public OrdersDTO searchOrder(String id) {
        String sql = "SELECT * FROM Orders WHERE id=?";

        try {
            Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement pstm = connection.prepareStatement(sql);

            pstm.setString(1, id);

            ResultSet rs = pstm.executeQuery();

            if (rs.next()) {
                return new OrdersDTO(
                        rs.getString("id"),
                        rs.getString("date"),
                        rs.getString("customerId")
                );
            }

        } catch (SQLException e) {
            System.out.println("Search Error: " + e.getMessage());
        }

        return null;
    }

    @Override
    public ObservableList<OrdersDTO> getAllOrders() {
        ObservableList<OrdersDTO> list = FXCollections.observableArrayList();
        String sql = "SELECT * FROM Orders";

        try {
            Connection connection = DBConnection.getInstance().getConnection();
            Statement stm = connection.createStatement();
            ResultSet rs = stm.executeQuery(sql);

            while (rs.next()) {
                list.add(new OrdersDTO(
                        rs.getString("id"),
                        rs.getString("date"),
                        rs.getString("customerId")
                ));
            }

        } catch (SQLException e) {
            System.out.println("Get All Error: " + e.getMessage());
        }

        return list;
    }
}
