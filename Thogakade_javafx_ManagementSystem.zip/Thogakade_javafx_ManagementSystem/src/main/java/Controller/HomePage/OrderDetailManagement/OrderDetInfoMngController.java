package Controller.HomePage.OrderDetailManagement;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.dto.OrderDetailDTO;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class OrderDetInfoMngController implements Initializable {

    @FXML private TableColumn<OrderDetailDTO, String> colItemCode;
    @FXML private TableColumn<OrderDetailDTO, String> colOrderId;
    @FXML private TableColumn<OrderDetailDTO, Integer> colQuantity;
    @FXML private TableColumn<OrderDetailDTO, Double> colUnitPrice;

    @FXML private TableView<OrderDetailDTO> tblOrderDetMangement;

    @FXML private TextField txtItemCode;
    @FXML private TextField txtOrderId;
    @FXML private TextField txtQuantity;
    @FXML private TextField txtUnitPrice;

    private final OrderDetMngController orderDetailService = new OrderDetMngController();

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        colOrderId.setCellValueFactory(new PropertyValueFactory<>("orderId"));
        colItemCode.setCellValueFactory(new PropertyValueFactory<>("itemCode"));
        colQuantity.setCellValueFactory(new PropertyValueFactory<>("qty"));
        colUnitPrice.setCellValueFactory(new PropertyValueFactory<>("unitPrice"));

        loadTable();

        tblOrderDetMangement.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) setSelectedValue(newVal);
        });
    }

    private void loadTable() {
        ObservableList<OrderDetailDTO> list = orderDetailService.getAllOrderDetails();
        tblOrderDetMangement.setItems(list);
    }

    private void setSelectedValue(OrderDetailDTO dto) {
        txtOrderId.setText(dto.getOrderId());
        txtItemCode.setText(dto.getItemCode());
        txtQuantity.setText(String.valueOf(dto.getQty()));
        txtUnitPrice.setText(String.valueOf(dto.getUnitPrice()));
    }

    private boolean validateFields() {
        if (txtOrderId.getText().isEmpty() || txtItemCode.getText().isEmpty() ||
                txtQuantity.getText().isEmpty() || txtUnitPrice.getText().isEmpty()) {

            new Alert(Alert.AlertType.WARNING, "Please fill all fields!").show();
            return false;
        }

        try {
            Integer.parseInt(txtQuantity.getText());
            Double.parseDouble(txtUnitPrice.getText());
        } catch (NumberFormatException e) {
            new Alert(Alert.AlertType.ERROR, "Quantity must be integer and Unit Price must be number!").show();
            return false;
        }
        return true;
    }

    @FXML
    void btnAdd(ActionEvent event) {
        if (!validateFields()) return;

        orderDetailService.btnAdd(
                txtOrderId.getText(),
                txtItemCode.getText(),
                Integer.parseInt(txtQuantity.getText()),
                Double.parseDouble(txtUnitPrice.getText())
        );

        loadTable();
        btnClear(event);

        new Alert(Alert.AlertType.INFORMATION, "Order Detail Added Successfully!").show();
    }

    @FXML
    void btnUpdate(ActionEvent event) {
        if (!validateFields()) return;

        orderDetailService.btnUpdate(
                txtOrderId.getText(),
                txtItemCode.getText(),
                Integer.parseInt(txtQuantity.getText()),
                Double.parseDouble(txtUnitPrice.getText())
        );

        loadTable();
        btnClear(event);

        new Alert(Alert.AlertType.INFORMATION, "Order Detail Updated Successfully!").show();
    }

    @FXML
    void btnDelete(ActionEvent event) {
        if (txtOrderId.getText().isEmpty() || txtItemCode.getText().isEmpty()) {
            new Alert(Alert.AlertType.WARNING, "Enter OrderId & ItemCode to delete!").show();
            return;
        }

        orderDetailService.btnDelete(txtOrderId.getText(), txtItemCode.getText());
        loadTable();
        btnClear(event);

        new Alert(Alert.AlertType.INFORMATION, "Order Detail Deleted Successfully!").show();
    }

    @FXML
    void btnClear(ActionEvent event) {
        txtOrderId.clear();
        txtItemCode.clear();
        txtQuantity.clear();
        txtUnitPrice.clear();
        tblOrderDetMangement.getSelectionModel().clearSelection();
    }

    public void btnMainMenue(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/HomePage.fxml"));
        Scene scene = new Scene(loader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    public void btnorderMng(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/OrderMngInfo.fxml"));
        Scene scene = new Scene(loader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    public void btnitemMng(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/ItemMngInfo.fxml"));
        Scene scene = new Scene(loader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    public void btnOrderDetMng(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/OrderDetMngInfo.fxml"));
        Scene scene = new Scene(loader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    public void btnCustomerMng(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/CustomerMngInfo.fxml"));
        Scene scene = new Scene(loader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
}
