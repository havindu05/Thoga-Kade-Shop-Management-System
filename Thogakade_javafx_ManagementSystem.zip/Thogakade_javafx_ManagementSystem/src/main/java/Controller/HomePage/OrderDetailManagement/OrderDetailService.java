package Controller.HomePage.OrderDetailManagement;

import javafx.collections.ObservableList;
import model.dto.OrderDetailDTO;

public interface OrderDetailService {

    void btnAdd(String orderId,String itemCode,int qty,double unitPrice);

    void btnUpdate(String orderId,String itemCode,int qty,double unitPrice);

    void btnDelete(String orderId,String itemCode);

    ObservableList<OrderDetailDTO> getAllOrderDetails();
}
