package Controller.HomePage.OrderDetailManagement;

import db.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.dto.OrderDetailDTO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class OrderDetMngController implements OrderDetailService {

    @Override
    public void btnAdd(String orderId, String itemCode, int qty, double unitPrice) {
        try {
            Connection connection = DBConnection.getInstance().getConnection();
            String SQL = "INSERT INTO OrderDetail (orderId, itemCode, qty, unitPrice) VALUES (?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(SQL);

            preparedStatement.setObject(1, orderId);
            preparedStatement.setObject(2, itemCode);
            preparedStatement.setObject(3, qty);
            preparedStatement.setObject(4, unitPrice);

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void btnUpdate(String orderId, String itemCode, int qty, double unitPrice) {
        try {
            Connection connection = DBConnection.getInstance().getConnection();
            String SQL = "UPDATE OrderDetail SET qty=?, unitPrice=? WHERE orderId=? AND itemCode=?";
            PreparedStatement preparedStatement = connection.prepareStatement(SQL);

            preparedStatement.setObject(1, qty);
            preparedStatement.setObject(2, unitPrice);
            preparedStatement.setObject(3, orderId);
            preparedStatement.setObject(4, itemCode);

            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void btnDelete(String orderId, String itemCode) {
        try {
            Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "DELETE FROM OrderDetail WHERE orderId=? AND itemCode=?"
            );

            preparedStatement.setObject(1, orderId);
            preparedStatement.setObject(2, itemCode);
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public ObservableList<OrderDetailDTO> getAllOrderDetails() {
        ObservableList<OrderDetailDTO> orderDetailDTOS = FXCollections.observableArrayList();

        try {
            Connection connection = DBConnection.getInstance().getConnection();
            String SQL = "SELECT * FROM OrderDetail";
            PreparedStatement preparedStatement = connection.prepareStatement(SQL);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                orderDetailDTOS.add(new OrderDetailDTO(
                        resultSet.getString("orderId"),
                        resultSet.getString("itemCode"),
                        resultSet.getInt("qty"),
                        resultSet.getDouble("unitPrice")
                ));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return orderDetailDTOS;
    }
}
